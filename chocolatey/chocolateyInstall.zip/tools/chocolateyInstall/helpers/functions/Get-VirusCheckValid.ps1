function Get-VirusCheckValid {
param(
  [string] $location,
  [string] $file = ''
)
  Write-Debug "Running 'Get-VirusCheckValid' with location:`'$location`', file: `'$file`'";

  Write-Debug "Right now there is no virus checking built in."
  #if ($settings:virusCheck) {

  #}

  #if virus check is invalid, throw here
}
